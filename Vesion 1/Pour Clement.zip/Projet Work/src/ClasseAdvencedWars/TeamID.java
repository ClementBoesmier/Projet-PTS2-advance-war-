package ClasseAdvencedWars;

public enum TeamID {
    RED,BLUE,NEUTRAL;
}
